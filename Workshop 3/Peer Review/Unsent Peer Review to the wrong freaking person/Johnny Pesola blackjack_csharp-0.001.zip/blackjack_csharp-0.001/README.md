# blackjack_csharp

Fork this code to work with C# in workshop 3.

Contains cs files and project files for Visual Studio 10. Also a modeling project is included, but this project will not load in certain versions of Visual Studio.
