DiceGame example in Python.
