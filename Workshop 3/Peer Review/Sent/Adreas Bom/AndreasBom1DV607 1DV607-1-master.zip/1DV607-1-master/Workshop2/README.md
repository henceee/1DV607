##INSTRUCTIONS

###Source code    
#####[/App/OOAD_Workshop2](https://github.com/AndreasBom/1DV607/tree/master/Workshop2/App/OOAD_Workshop2/OOAD_Workshop2)    
   
###Executable (console application)
#####[Link](https://github.com/AndreasBom/1DV607/releases)   
Requirements: Windows. Tested on Windows 10.   
   
###[Documentation](https://github.com/AndreasBom/1DV607/tree/master/Workshop2/Documentation)   
Folder contains:
#####ClassDiagramAssociations.jpg   
#####ClassDiagramAssociationsFinal.jpg (added after peer review)   
#####Classdiagram.jpg   
#####PackageAndThereRelations.jpg   
#####SequenceDiagramNewMember.jpg   
#####SequenceDiagramShowMember.jpg    


