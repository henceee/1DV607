<h2>Authors</h2>
<h3>Grade 2</h3>
Kristoffer Karlsson - kk222hk<br />
Jan Tran - jt222ic

<h2>Comments</h2>
Authentication is excluded from the domain model, since it is a software concern and not a part of the problem domain (the yacht club).<br />
If a boat is registered during pre-season, the berth is assigned directly by the secretary when season starts. Otherwise, it's assigned by a reservation proposal accepted by the secretary.
