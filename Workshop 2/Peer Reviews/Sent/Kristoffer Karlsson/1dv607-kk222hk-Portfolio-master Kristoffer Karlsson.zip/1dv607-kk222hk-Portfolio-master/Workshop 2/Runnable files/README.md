Put these two files (text file and .exe file) in a folder and start the .exe file to run the program.
